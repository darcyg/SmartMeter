#define HAVE_FCNTL_H
#define HAVE_UNISTD_H
#define HAVE_SYS_TIME_H
